




install npm package in "front-end" nextjs app folder or directory----otherwise, node_modules is created outside of the next-js project

