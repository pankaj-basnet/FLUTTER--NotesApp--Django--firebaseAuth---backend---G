created github repo

created virtual environment

created requirements.txt -----write down required packages to install

pip install -r requirements.txt

django-admin startproject Django_Backend .

python manage.py startapp useraccount

python manage.py startapp property


my to do list -- create "CustomUserManager" and "User" models

my to do list -- settings.py ---- add "AUTH_USER_MODEL" and other things

<!-- settings.py -->
ALLOWED_HOSTS = ['*'] ----------mb- wrong ---check later if project doesnot run


